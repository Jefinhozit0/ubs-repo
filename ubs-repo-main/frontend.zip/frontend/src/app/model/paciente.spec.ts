import { Paciente } from './paciente';

describe('Paciente', () => {
  it('should create an instance', () => {
    expect(new Paciente()).toBeTruthy();
  });
});
